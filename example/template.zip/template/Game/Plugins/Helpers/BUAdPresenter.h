//
//  BUAdPresenter.h
//  TestWebKit
//
//  Created by Yaroslav Zhurakovskiy on 16.01.2020.
//  Copyright © 2020 Yaroslav Zhurakovskiy. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface BUAdPresenter : NSObject

@end

NS_ASSUME_NONNULL_END
