//
//  TestMTGBannerViewController.h
//  TestWebKit
//
//  Created by Yaroslav Zhurakovskiy on 16.01.2020.
//  Copyright © 2020 Yaroslav Zhurakovskiy. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface TestMTGBannerViewController : UIViewController

@end

NS_ASSUME_NONNULL_END
