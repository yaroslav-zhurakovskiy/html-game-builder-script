//import BUAdSDK
//
//let normal_splash_ID = "800546808"
//
//
//class Presenter {
//    func show(fromRootViewController vc: UIViewController) {
//        let video = BUFullscreenVideoAd(slotID: normal_splash_ID)
//        video.show(fromRootViewController: vc)
//    }
//}
//
//
//class BUAdPresenter: NSObject, BUSplashAdDelegate {
//    override init() {
//        BUAdSDKManager.setAppID("5000546")
//        BUAdSDKManager.setIsPaidApp(true)
//        
//        super.init()
//    }
//    
//    func showSplashAdd(from viewController: UIViewController) {
//        let frame = viewController.view.frame
//        let splashView = BUSplashAdView(slotID: normal_splash_ID, frame: frame)
//        // tolerateTimeout = CGFLOAT_MAX , The conversion time to milliseconds will be equal to 0
//        splashView.tolerateTimeout = 10;
//        splashView.delegate = self
//        
//        splashView.loadAdData()
//        viewController.view.addSubview(splashView)
//        splashView.rootViewController = viewController
//    }
//    
//    func splashAdDidClose(_ splashAd: BUSplashAdView) {
//        
//    }
//    
//    func splashAd(_ splashAd: BUSplashAdView, didFailWithError error: Error?) {
//        splashAd.removeFromSuperview()
//    }
//    
//    
//    func splashAdWillVisible(_ splashAd: BUSplashAdView) {
//        
//    }
//}
