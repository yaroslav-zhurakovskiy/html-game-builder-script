//
//  BUAdPresenter.m
//  TestWebKit
//
//  Created by Yaroslav Zhurakovskiy on 16.01.2020.
//  Copyright © 2020 Yaroslav Zhurakovskiy. All rights reserved.
//

#import "BUAdPresenter.h"

#import <BUAdSDK/BUAdSDK.h>

@implementation BUAdPresenter

@end
