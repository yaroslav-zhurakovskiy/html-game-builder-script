#import "TestViewController.h"
#import "NSObject+Logging.h"

#import <MTGSDK/MTGSDK.h>
#import <MTGSDK/MTGNativeAdManager.h>

static NSString * const KNativeUnitID = @"193839";
static NSString * const KPlacementID = @"";

@interface TestViewController ()<MTGNativeAdManagerDelegate,MTGMediaViewDelegate>

@property (nonatomic, strong) MTGNativeAdManager *nativeVideoAdManager;
@property (weak, nonatomic) IBOutlet MTGMediaView *mMediaView;

@end

@implementation TestViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    if (_nativeVideoAdManager) {
        NSArray *templates = @[[MTGTemplate templateWithType:MTGAD_TEMPLATE_BIG_IMAGE adsNum:1]];
        _nativeVideoAdManager = [[MTGNativeAdManager alloc] initWithUnitID:KNativeUnitID
                                                             fbPlacementId:KPlacementID
                                                        supportedTemplates:templates
                                                            autoCacheImage:NO
                                                                adCategory:0 presentingViewController:self];
        _nativeVideoAdManager.delegate = self;
        [_nativeVideoAdManager loadAds];
    }
}



#pragma mark AdManger delegate
- (void)nativeAdsLoaded:(NSArray *)nativeAds nativeManager:(nonnull MTGNativeAdManager *)nativeManager
{
    
    if (nativeAds.count > 0) {
        MTGCampaign *campain = nativeAds[0];
        self.mMediaView.delegate = self;
        //Set the camgaign fot the MTGmediaview
        [self.mMediaView setMediaSourceWithCampaign:campain unitId:@"your unitid"];
//        self.appNameLabel.text = campain.appName;
//        self.appDescLabel.text = campain.appDesc;
//        [self.adCallButton setTitle:campaign.adCall forState:UIControlStateNormal];
        [campain loadIconUrlAsyncWithBlock:^(UIImage *image) {
            if (image) {
//                [self.iconImageView setImage:image];
            }
        }];
        // Set the MTGAdchoiceview with frame and campaign
        if (CGSizeEqualToSize(campain.adChoiceIconSize, CGSizeZero)) { // Suggest to hide the adChoicesView when the campaign.adChoiceIconSize equals to zero
//            self.adChoicesView.hidden = YES;
        }
        else {
//            self.adChoicesView.hidden = NO;
//            // Suggest to set the adChoicesView'size depends on  campaign.adChoiceIconSize
//            self.adChoicesViewWithConstraint.constant = campaign.adChoiceIconSize.width;
//            self.adChoicesViewHeightConstraint.constant = campaign.adChoiceIconSize.height;
        }
//        self.adChoicesView.campaign = campaign;
        
//        [ self.nativeVideoAdManager registerViewForInteraction:self.appDescLabel.text withCampaign:campain];
    }
    
}

- (void)nativeAdsFailedToLoadWithError:(NSError *)error nativeManager:(nonnull MTGNativeAdManager *)nativeManager
{
    [self log:[NSString stringWithFormat:@"Failed to load ads, error:%@", error.localizedDescription]];
}

- (void)nativeAdImpressionWithType:(MTGAdSourceType)type nativeManager:(MTGNativeAdManager *)nativeManager
{
    
}


#pragma mark MediaView delegate
- (void)MTGMediaViewWillEnterFullscreen:(MTGMediaView *)mediaView{
    [self log:@"MTGMedia View Will Enter Full Screen"];
}


- (void)MTGMediaViewDidExitFullscreen:(MTGMediaView *)mediaView{
    [self log:@"MTGMedia View Did Exit Full Screen"];
}


#pragma mark MediaView and AdManger Click delegate
- (void)nativeAdDidClick:(MTGCampaign *)nativeAd
{
    [self log:@"Registerview or mediaVie Ad is clicked"];
}

- (void)nativeAdDidClick:(MTGCampaign *)nativeAd nativeManager:(nonnull MTGNativeAdManager *)nativeManager
{
    [self log:@"Registerview Ad is clicked"];
}
- (void)nativeAdDidClick:(MTGCampaign *)nativeAd mediaView:(nonnull MTGMediaView *)mediaView
{
    [self log:@"MTGMediaView Ad is clicked"];
}

@end
